from flask import Flask
import cv2
import threading
import smtplib
import ssl
from email.message import EmailMessage
import time

app = Flask(__name__)

EMAIL_SENDER = "floormat394@gmail.com"
EMAIL_PASSWORD = "eqdcsbberzctlcfy"  # App password, not your main email password
EMAIL_RECEIVER = "kavirajan0211@gmail.com"

def send_email_with_attachment(image_path):
    try:
        msg = EmailMessage()
        msg["Subject"] = "Motion Detected - Image Attached"
        msg["From"] = EMAIL_SENDER
        msg["To"] = EMAIL_RECEIVER
        msg.set_content("Motion was detected. See attached image.")

        # Attach image
        with open(image_path, "rb") as f:
            file_data = f.read()
            file_name = image_path
            msg.add_attachment(file_data, maintype="image", subtype="jpeg", filename=file_name)

        # Send email
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(EMAIL_SENDER, EMAIL_PASSWORD)
            server.send_message(msg)

        print(f"Email sent to {EMAIL_RECEIVER}")
    except Exception as e:
        print(f"Failed to send email: {e}")

def capture_and_send():
    cam = cv2.VideoCapture(0)
    ret, frame = cam.read()
    if ret:
        filename = f"motion_{int(time.time())}.jpg"
        cv2.imwrite(filename, frame)
        print("Image saved as", filename)
        send_email_with_attachment(filename)
    cam.release()

@app.route('/')
def home():
    return "Motion Detection Server is Running"

@app.route('/motion', methods=['GET'])
def motion_triggered():
    print("Motion detected! Taking picture and sending email...")
    threading.Thread(target=capture_and_send).start()
    return "OK", 200

if __name__ == '__main__':
    print("Starting motion detection server on port 5000...")
    app.run(host='0.0.0.0', port=5000)
